def sends():
	print("发送短信")
